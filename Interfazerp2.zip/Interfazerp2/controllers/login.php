<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../consultas/conexion.php');
    $nombre_usuario = $_POST['nombre_usuario'];
    $contrasena = $_POST['contrasena'];

    // Consulta para verificar el usuario y la contraseña
    $sql = "SELECT id FROM usuarios WHERE nombre_usuario='$nombre_usuario' AND contrasena='$contrasena'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Usuario autenticado, iniciar sesión
        $_SESSION['nombre_usuario'] = $nombre_usuario;
        header("Location: ../ordenes/index.php");
        exit(); // Asegura que el script se detenga después de redirigir
    } else {
        // Usuario no encontrado o contraseña incorrecta
        // Redirige de vuelta al inicio de sesión con un mensaje de error
        header("Location: ../login.php?error=Usuario o contraseña incorrectos");
        exit(); // Asegura que el script se detenga después de redirigir
    }

    $conn->close();
}
?>
