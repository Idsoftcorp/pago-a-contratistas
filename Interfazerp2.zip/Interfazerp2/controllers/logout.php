<?php
// Destruir todas las variables de sesión
session_start();
$_SESSION = array();

// Borrar la sesión
session_destroy();

// Redirigir al usuario al formulario de inicio de sesión
header("Location: ../login.php");
exit();
?>