<?php
include('conexion.php');
date_default_timezone_set('UTC');

function graficaTareas($inicio = null, $fin = null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT COUNT(*) AS ordenes FROM `detalle_produccion` WHERE `Tipo` = 'ORDENES' AND (`Estatus`='LIQUIDADO' OR `Estatus`='CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $ordenes = $row['ordenes'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    $query = "SELECT COUNT(*) as garantias FROM `detalle_produccion` WHERE `Tipo` = 'EN GARANTIA'  AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $garantias = $row['garantias'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    $query = "SELECT COUNT(*) as cambaceo FROM `detalle_produccion` WHERE `Tipo` = 'CAMBACEO'AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $cambaceo = $row['cambaceo'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    return array(
        'ordenes' => $ordenes,
        'garantias' => $garantias,
        'cambaceo' => $cambaceo,
    );
    $conn->close();
}

function graficaPorDivision($inicio = null, $fin = null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }


    $query = "SELECT DIRECCION,
    SUM(CASE WHEN Tipo = 'ORDENES' THEN 1 ELSE 0 END) AS ordenes,
    SUM(CASE WHEN Tipo = 'EN GARANTIA' THEN 1 ELSE 0 END) AS garantias,
    SUM(CASE WHEN Tipo = 'CAMBACEO' THEN 1 ELSE 0 END) AS cambaceos
    FROM detalle_produccion  WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY DIRECCION";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['DIRECCION'], intval($row['ordenes']), intval($row['garantias']), intval($row['cambaceos']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

function graficaPorArea($inicio = null, $fin = null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT AREA,
    SUM(CASE WHEN Tipo = 'ORDENES' THEN 1 ELSE 0 END) AS ordenes,
    SUM(CASE WHEN Tipo = 'EN GARANTIA' THEN 1 ELSE 0 END) AS garantias,
    SUM(CASE WHEN Tipo = 'CAMBACEO' THEN 1 ELSE 0 END) AS cambaceos
    FROM detalle_produccion  WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY AREA ORDER BY  ordenes DESC, garantias DESC, cambaceos DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['AREA'], intval($row['ordenes']), intval($row['garantias']), intval($row['cambaceos']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}


function graficaProductividad()
{
    global $conn;

    $query = "SELECT JUNTAR,
    SUM(CASE WHEN Tipo = 'ORDENES' THEN 1 ELSE 0 END) AS os,
    SUM(CASE WHEN Tipo = 'EN GARANTIA' THEN 1 ELSE 0 END) AS garantias,
    SUM(CASE WHEN Tipo = 'CAMBACEO' THEN 1 ELSE 0 END) AS cambaceos
    FROM detalle_produccion 
    GROUP BY JUNTAR
    ORDER BY CAST(SUBSTRING_INDEX(JUNTAR, ' ', -1) AS UNSIGNED)";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['JUNTAR'], intval($row['os']), intval($row['garantias']), intval($row['cambaceos']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}


$inicio = isset($_GET['inicio']) ? $_GET['inicio'] :  null;
$fin = isset($_GET['fin']) ? $_GET['fin'] :  null;

$tareas = graficaTareas($inicio, $fin);
$data_grafica_div = graficaPorDivision($inicio, $fin);
$data_grafica_area = graficaPorArea($inicio, $fin);
$prod = graficaProductividad();


$garantias = $tareas['garantias'];
$ordenes = $tareas['ordenes'];
$cambaceos = $tareas['cambaceo'];
$tareas = $garantias + $ordenes + $cambaceos;


echo json_encode([
    'division' => $data_grafica_div,
    'area' => $data_grafica_area,
    'ordenes' => $ordenes,
    'garantias' => $garantias,
    'cambaceos' => $cambaceos,
    'tareas' => $tareas,
    'prod' => $prod
]);
