<?php
include('conexion.php');
date_default_timezone_set('UTC');



function graficaPorArea($division = null, $inicio = null, $fin = null)
{
    global $conn;
    $div_query = "";
    if ($division !== null) {
        $div_query = "DIRECCION ='$division'";
    }
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }
    $query = "SELECT AREA,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA' AND `CALIF` = 'OBJETADA' AND Tipo = 'ORDENES' THEN 1 ELSE 0 END) AS fibra    
    FROM detalle_produccion WHERE $div_query AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY AREA ORDER BY  fibra DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['AREA'], intval($row['fibra']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}
function graficaPorCope($area = null, $inicio = null, $fin = null)
{
    global $conn;
    $div_area = "";
    if ($area !== null) {
        $div_area = "AREA ='$area'";
    }

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT COPE2,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA' AND `CALIF` = 'OBJETADA'  AND Tipo = 'ORDENES' THEN 1 ELSE 0 END) AS fibra
    FROM detalle_produccion WHERE $div_area AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY COPE2 ORDER BY fibra DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['COPE2'], intval($row['fibra']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}
function graficaPorcontratista($cope = null, $inicio = null, $fin = null)
{
    global $conn;

    $div_cope = "";
    if ($cope !== null) {
        $div_cope = "dp.COPE2 ='$cope'";
    }
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }
    $query = "SELECT t.Contratista AS nombre_contratista,
    SUM(CASE WHEN dp.`Tipo Banda` = 'FIBRA' AND dp.`CALIF` = 'OBJETADA'  AND dp.`Tipo` = 'ORDENES'  THEN 1 ELSE 0 END) AS fibra
    FROM detalle_produccion dp 
    INNER JOIN tecnicos t ON dp.Expediente = t.Expediente_tec
    WHERE $div_cope  AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY t.Contratista
    ORDER BY fibra DESC";
    
    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['nombre_contratista'], intval($row['fibra']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

function graficaPorTecnico($contratista = null,$cope = null, $inicio = null, $fin = null)
{
    global $conn;

    $query_contratista = "";
    if ($contratista !== null) {
        $query_contratista = "WHERE t.Contratista ='$contratista'";
    }
    $query_cope = "";
    if ($cope !== null) {
        $query_cope = "AND dp.COPE2 ='$cope'";
    }
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }
    $query = "SELECT dp.Tecnico AS tecnico,
    SUM(CASE WHEN dp.`Tipo Banda` = 'FIBRA' AND dp.`CALIF` = 'OBJETADA'  AND dp.`Tipo` = 'ORDENES' THEN 1 ELSE 0 END) AS fibra
    FROM detalle_produccion dp 
    INNER JOIN tecnicos t ON dp.Expediente = t.Expediente_tec
    -- WHERE t.Contratista='CARLOS ANDRADE'
    $query_contratista
    $query_cope
    AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY dp.Tecnico
    ORDER BY fibra DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['tecnico'], intval($row['fibra']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

$division = isset($_GET['division']) ? $_GET['division'] :  null;
$area = isset($_GET['area']) ? $_GET['area'] :  null;
$cope = isset($_GET['cope']) ? $_GET['cope'] :  null;
$contratista = isset($_GET['contratista']) ? $_GET['contratista'] :  null;
$inicio = isset($_GET['inicio']) ? $_GET['inicio'] :  null;
$fin = isset($_GET['fin']) ? $_GET['fin'] :  null;

$data_grafica_cope = graficaPorCope($area, $inicio, $fin);
$data_grafica_area = graficaPorArea($division, $inicio, $fin);
$data_grafica_contratista = graficaPorcontratista($cope, $inicio, $fin);
$data_grafica_tecnico = graficaPorTecnico($contratista, $cope, $inicio, $fin);

echo json_encode([
    'cope' => $data_grafica_cope,
    'area' => $data_grafica_area,
    'contratista' => $data_grafica_contratista,
    'tecnico' => $data_grafica_tecnico,
]);
