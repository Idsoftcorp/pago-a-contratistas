<?php
include('conexion.php');
date_default_timezone_set('UTC');

function graficaOrdenes($inicio=null,$fin=null)
{
    global $conn;
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }
    $query = "SELECT COUNT(*) as fibra FROM `detalle_produccion` WHERE  `Tipo Banda` = 'FIBRA' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $fibra = $row['fibra'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    $query = "SELECT COUNT(*) as cobre FROM `detalle_produccion` WHERE `Tipo Banda` = 'COBRE' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $cobre = $row['cobre'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
    return array(
        'fibra' => $fibra,
        'cobre' => $cobre
    );
    $conn->close();
}

function graficaPorDivision($inicio=null,$fin=null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT DIRECCION,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') THEN 1 ELSE 0 END) AS fibra,
    SUM(CASE WHEN `Tipo Banda` = 'COBRE' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') THEN 1 ELSE 0 END) AS cobre
    FROM detalle_produccion WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY DIRECCION";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['DIRECCION'], intval($row['fibra']),intval($row['cobre']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

function graficaPorArea($inicio=null,$fin=null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT AREA,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') THEN 1 ELSE 0 END) AS fibra,
    SUM(CASE WHEN `Tipo Banda` = 'COBRE' AND `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') THEN 1 ELSE 0 END) AS cobre
    FROM detalle_produccion WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY AREA ORDER BY  fibra DESC ,cobre DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['AREA'], intval($row['fibra']), intval($row['cobre']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

$inicio = isset($_GET['inicio']) ? $_GET['inicio'] :  null;
$fin = isset($_GET['fin']) ? $_GET['fin'] :  null;

$ordenes = graficaOrdenes($inicio,$fin);
$data_grafica_div = graficaPorDivision($inicio,$fin);
$data_grafica_area = graficaPorArea($inicio,$fin);

$fibra = $ordenes['fibra'];
$cobre = $ordenes['cobre'];


$total_ordenes = $fibra + $cobre ;
echo json_encode([
    'division' => $data_grafica_div,
    'area' => $data_grafica_area,
    'fibra' => $fibra,
    'cobre' => $cobre,
    'ordenes' => $total_ordenes,
]);
