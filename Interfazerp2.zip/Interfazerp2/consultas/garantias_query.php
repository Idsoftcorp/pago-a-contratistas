<?php
include('conexion.php');
date_default_timezone_set('UTC');

function graficaGarantias()
{
    global $conn;

    $query = "SELECT COUNT(*) as fibra FROM `detalle_produccion` WHERE `Tipo Banda` = 'FIBRA' AND `Tipo` = 'EN GARANTIA' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO')";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $fibra = $row['fibra'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
    $query = "SELECT COUNT(*) as cobre FROM `detalle_produccion` WHERE `Tipo Banda` = 'COBRE' AND `Tipo` = 'EN GARANTIA' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO')";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $cobre = $row['cobre'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    return array(
        'fibra' => $fibra,
        'cobre' => $cobre,
    );
    $conn->close();
}

function graficaPorDivision()
{
    global $conn;
    
    $query = "SELECT DIRECCION,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA'  THEN 1 ELSE 0 END) AS fibra,
    SUM(CASE WHEN`Tipo Banda` = 'COBRE'  THEN 1 ELSE 0 END) AS cobre
    FROM detalle_produccion
    GROUP BY DIRECCION";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['DIRECCION'], intval($row['fibra']), intval($row['cobre']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

function graficaPorArea()
{
    global $conn;
    
    $query = "SELECT AREA,
    SUM(CASE WHEN `Tipo Banda` = 'FIBRA'  THEN 1 ELSE 0 END) AS fibra,
    SUM(CASE WHEN`Tipo Banda` = 'COBRE'  THEN 1 ELSE 0 END) AS cobre
    FROM detalle_produccion
    GROUP BY AREA ORDER BY  fibra DESC ,cobre DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['AREA'], intval($row['fibra']), intval($row['cobre']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

$garantias = graficaGarantias();
$data_grafica_div=graficaPorDivision();
$data_grafica_area=graficaPorArea();

$fibra = $garantias['fibra'];
$cobre = $garantias['cobre'];
$total_garantias =$fibra+$cobre;
echo json_encode([
    'division'=>$data_grafica_div,
    'area'=>$data_grafica_area,
    'fibra'=>$fibra,
    'cobre'=>$cobre,
    'total' => $total_garantias
]);
