<?php
$servername = "127.0.0.1";
$username = "root";
$password = "12345678";
$dbname = "enlace-digital";

// Crear una conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}


?>