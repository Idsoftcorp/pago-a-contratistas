<?php
include('conexion.php');
date_default_timezone_set('UTC');

function graficaOrdenes($inicio=null,$fin=null)
{
    global $conn;
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT COUNT(*) as completadas FROM `detalle_produccion` WHERE `CALIF` = 'COMPLETADA' AND `Tipo` = 'ORDENES' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $completadas = $row['completadas'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    $query = "SELECT COUNT(*) as objetadas FROM `detalle_produccion` WHERE `CALIF` = 'OBJETADA' AND `Tipo` = 'ORDENES'AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $objetadas = $row['objetadas'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    $query = "SELECT COUNT(*) as reagendadas FROM `detalle_produccion` WHERE `CALIF` = 'REAGENDA' AND (`Estatus` = 'LIQUIDADO' OR `Estatus` = 'CERRADO') AND `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $row = $resultado->fetch_assoc();
        $reagendadas = $row['reagendadas'];
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }

    return array(
        'completadas' => $completadas,
        'objetadas' => $objetadas,
        'reagendadas' => $reagendadas,
    );
    $conn->close();
}

function graficaPorDivision($inicio=null,$fin=null)
{
    global $conn;
    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }
    $query = "SELECT DIRECCION,
    SUM(CASE WHEN `CALIF` = 'COMPLETADA' THEN 1 ELSE 0 END) AS completadas,
    SUM(CASE WHEN `CALIF` = 'OBJETADA' THEN 1 ELSE 0 END) AS objetadas,
    SUM(CASE WHEN `CALIF` = 'REAGENDA' THEN 1 ELSE 0 END) AS reagendadas
    FROM detalle_produccion WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY DIRECCION";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['DIRECCION'], intval($row['completadas']), intval($row['objetadas']), intval($row['reagendadas']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

function graficaPorArea($inicio=null,$fin=null)
{
    global $conn;

    $inicio_query = "";
    if ($inicio !== null) {
        $inicio_query = $inicio;
        
    }
    $fin_query = "";
    if ($fin !== null) {
        $fin_query = $fin;
    }

    $query = "SELECT AREA,
    SUM(CASE WHEN `CALIF` = 'COMPLETADA'THEN 1 ELSE 0 END) AS completadas,
    SUM(CASE WHEN `CALIF` = 'OBJETADA' THEN 1 ELSE 0 END) AS objetadas,
    SUM(CASE WHEN `CALIF` = 'REAGENDA' THEN 1 ELSE 0 END) AS reagendadas
    FROM detalle_produccion WHERE `Fecha Liquidada2` BETWEEN '$inicio_query' AND '$fin_query'
    GROUP BY AREA ORDER BY  completadas DESC, objetadas DESC, reagendadas DESC";

    $resultado = $conn->query($query);

    if ($resultado) {
        $data = array();
        while ($row = $resultado->fetch_assoc()) {
            $data[] = array($row['AREA'], intval($row['completadas']), intval($row['objetadas']), intval($row['reagendadas']));
        }
        return $data;
    } else {
        return "Error al ejecutar la consulta: " . $conn->error;
    }
}

$inicio = isset($_GET['inicio']) ? $_GET['inicio'] :  null;
$fin = isset($_GET['fin']) ? $_GET['fin'] :  null;

$ordenes = graficaOrdenes($inicio,$fin);
$data_grafica_div = graficaPorDivision($inicio,$fin);
$data_grafica_area = graficaPorArea($inicio,$fin);

$completadas = $ordenes['completadas'];
$objetadas = $ordenes['objetadas'];
$reagendadas = $ordenes['reagendadas'];

$total_ordenes = $completadas + $reagendadas + $objetadas;


echo json_encode([
    'division' => $data_grafica_div,
    'area' => $data_grafica_area,
    'completadas' => $completadas,
    'objetadas' => $objetadas,
    'reagendadas' => $reagendadas,
    'ordenes' => $total_ordenes,
]);
