<?php
session_start();

// Si el usuario no ha iniciado sesión, redirigir al formulario de inicio de sesión
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: ../login.php");
    exit();
}

include('../includes/header.php') ?>
<div class="container-fluid">

    <div id="reportrange" class="form-control" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%; margin-bottom:20px; text-align: center;">
        <i class="fa fa-calendar"></i> &nbsp;
        <span><i class="fa fa-caret-down"></i></span>
    </div>
    <!-- <input type="text" id="reportrange" class="form-control" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%; margin-bottom:20px; text-align: center;"> -->
    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
        <div class="card mx-2" style="align-items: center; justify-content:baseline; width:40vh; height:20vh;background-color:#4289F8 ">
            <div style="margin-top:25px">
                <h4 class="text-center text-white mt-2" style="font-size:35px"><i class="fas fa-coins" style="display: inline-block;"></i>
                    <div id="total_tareas" style="display: inline-block;"></div> Registros
                </h4>
            </div>
        </div>
        <div class="card btn mx-2" style="align-items: center; width:40vh; height:20vh;background-color:#4289F8">
            <div style="margin-top:20px">
                <h4 class="text-center text-white mt-2" style="font-size:35px"><a href="ordenes.php" style="text-decoration: none; color:white"><i class="fa-solid fa-file-lines" style="display: inline-block;"></i>
                        <div id="total_ordenes" style="display: inline-block;"></div> Ordenes
                    </a></h4>
            </div>
        </div>
        <div class="card btn mx-2 " style="width:40vh; height:20vh;background-color:#4289F8">
            <div style="margin-top:20px">
                <h4 class="text-center text-white mt-2" style="font-size:35px"><a href="garantias.php" style="text-decoration: none; color:white"><i class="fa-solid fa-file-excel" style="display: inline-block;"></i>
                        <div id="total_garantias" style="display: inline-block;"></div> Garantias
                    </a></h4>
            </div>
        </div>

        <div class="card btn mx-2 " style="width:40vh; height:20vh;background-color:#4289F8;">
            <div style="margin-top:20px">
                <h4 class="text-center text-white mt-2" style="font-size:35px"><a href="" style="text-decoration: none; color:white"><i class="fa-solid fa-arrows-turn-to-dots"></i>
                        <div id="total_cambaceo" style="display: inline-block;"></div> Cambaceo
                    </a></h4>
            </div>
        </div>
    </div>

</div>

<div class="container-fluid">
    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">

        <div class="card  mx-2 " style="width:400px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_liquidadas" style="height: 500px; "></div>
        </div>
        <div class="card  mx-2 " style="width:780px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive " id="grafica2" style="height: 500px;"></div>
        </div>

    </div>


</div>

<div class="container-fluid">
    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
        <div class="card  mx-2 " style="width:1270px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_prod_empresa" style="height: 500px;"></div>
        </div>
        <div class="card  mx-2" style="width:1270px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_area" style="height: 500px;"></div>
        </div>
    </div>
</div>
<?php include('../includes/footer.php') ?>
<script>
    $(document).ready(function() {
        // Id de las graficas
        var grafico_liquidadas = echarts.init(document.getElementById('grafica_liquidadas'));
        var grafico_prod_empresa = echarts.init(document.getElementById('grafica_prod_empresa'));
        var grafico_prod__division = echarts.init(document.getElementById('grafica2'));
        var grafico_area = echarts.init(document.getElementById('grafica_area'));

        // Valores de fecha inicial y final
        var start = moment().subtract(30, 'days');
        var end = moment();

        // Idioma del Date Range Picker
        moment.locale('es');

        // Graficas
        function cb(start, end) {
            $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));

            var requestData = {
                inicio: start.format('YYYY-MM-DD'), // Formatea la fecha de inicio
                fin: end.format('YYYY-MM-DD'), // Formatea la fecha de final
            }
            $.ajax({
                url: '../consultas/tareas_query.php',
                type: 'GET',
                dataType: 'json',
                data: requestData,
                success: function(response) {
                    // Actualiza la gráfica con los datos obtenidos
                    var opciones = {
                        title: {
                            text: 'Tareas',
                            left: 'center',
                            top: 20,
                            z: 5,

                        },
                        tooltip: {
                            trigger: 'item',
                            formatter: '{a} <br/>{b}: {c} ({d}%)',
                        },
                        legend: {
                            top: '10%',
                            left: 'center',

                        },
                        series: [{
                            top: '5%',
                            name: '',
                            type: 'pie',
                            radius: ['40%', '80%'],
                            avoidLabelOverlap: false,
                            itemStyle: {
                                borderRadius: 10,
                                borderColor: '#fff',
                                borderWidth: 4
                            },
                            label: {
                                show: false,
                                position: 'top'
                            },
                            emphasis: {
                                label: {
                                    show: true,
                                    fontSize: 40,
                                    fontWeight: 'bold'
                                }
                            },
                            labelLine: {
                                show: true
                            },
                            data: [{
                                value: response.ordenes,
                                name: 'Ordenes',
                                // emphasis: {
                                //     focus: 'series'
                                // },
                                itemStyle: {
                                    color: '#4F71F1', // Cambiar el color de las barras de órdenes
                                },
                                label: {
                                    show: true, // Mostrar el valor sobre la barra
                                    position: 'inside', // Posición del valor (puede ser 'top', 'insideTop', 'inside', etc.)
                                    formatter: 'Ordenes {d}%'

                                }

                            }, {
                                value: response.garantias,
                                name: 'Garantias',
                                // emphasis: {
                                //     focus: 'series'
                                // },
                                itemStyle: {
                                    color: '#4FF1D4', // Cambiar el color de las barras de órdenes

                                },


                                label: {
                                    show: true, // Mostrar el valor sobre la barra
                                    position: 'inside', // Posición del valor (puede ser 'top', 'insideTop', 'inside', etc.)
                                    formatter: 'Garantias {d}%'
                                }
                            }, {
                                value: response.cambaceos,
                                name: 'Cambaceos',
                                // emphasis: {
                                //     focus: 'series'
                                // },
                                itemStyle: {
                                    color: '#56F14F', // Cambiar el color de las barras de órdenes

                                },


                                label: {
                                    show: true, // Mostrar el valor sobre la barra
                                    position: 'inside', // Posición del valor (puede ser 'top', 'insideTop', 'inside', etc.)
                                    formatter: 'Cambaceos {d}%'
                                }
                            }]
                        }]
                    };
                    // var grafico_liquidadas = echarts.init(document.getElementById('grafico_liquidadas'));
                    grafico_liquidadas.setOption(opciones);
                    grafico_liquidadas.on('click', function(params) {
                        // Verifica si el clic se realizó en la barra de "Ordenes"
                        if (params.name === 'Ordenes') {
                            // Redirecciona a la página deseada
                            var urlDestino = 'ordenes.php?inicio=' + encodeURIComponent(requestData.inicio) + '&fin=' + encodeURIComponent(requestData.fin)
                            // Redirecciona a la página deseada con los parámetros de fecha
                            window.location.href = urlDestino;
                        }
                    });

                    option_area = {
                        title: {
                            text: 'Tareas de area',
                            left: 'center',
                            top: 15,
                            z: 5
                        },

                        tooltip: {
                            trigger: 'item'
                        },
                        label: {
                            show: false, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras
                        },
                        legend: {
                            top: '8%',
                            left: 'center',
                        },
                        grid: {
                            top: '20%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        dataset: [{
                            source: response.area,
                            dimensions: ['area', 'ordenes', 'garantias', 'cambaceo'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                rotate: 45,
                            },
                            axisTick: {
                                show: false,
                            },
                        },
                        yAxis: {},
                        series: [{
                                name: 'Ordenes',
                                type: 'bar',
                                encode: {
                                    y: 'ordenes',
                                    x: 'area'
                                },
                                itemStyle: {
                                    color: '#4F71F1' // Cambiar el color de las barras de órdenes
                                },
                                emphasis: {
                                    focus: 'series'
                                },
                                datasetIndex: 0
                            },
                            {
                                name: 'Garantias',
                                type: 'bar',
                                encode: {
                                    y: 'garantias',
                                    x: 'area'
                                },
                                itemStyle: {
                                    color: '#4FF1D4' // Cambiar el color de las barras de garantías
                                },
                                emphasis: {
                                    focus: 'series'
                                },
                                datasetIndex: 0
                            },
                            {
                                name: 'Cambaceos',
                                type: 'bar',
                                encode: {
                                    y: 'cambaceos',
                                    x: 'area'
                                },
                                itemStyle: {
                                    color: '#56F14F' // Cambiar el color de las barras de garantías
                                },
                                emphasis: {
                                    focus: 'series'
                                },
                                datasetIndex: 0
                            }
                        ]
                    };
                    grafico_area.setOption(option_area);
                    grafico_area.on('click', function(params) {
                        if (params.seriesName === 'Ordenes') {
                            var urlDestino = 'ordenes.php?inicio=' + encodeURIComponent(requestData.inicio) + '&fin=' + encodeURIComponent(requestData.fin)
                            // Redirecciona a la página deseada con los parámetros de fecha
                            window.location.href = urlDestino;
                        }
                    });


                    option = {
                        title: {
                            text: 'Tareas division',
                            left: 'center',
                            top: 20,
                            z: 5

                        },
                        tooltip: {
                            trigger: 'item'
                        },
                        legend: {
                            top: '10%',
                            left: 'center'
                        },
                        grid: {
                            top: '18%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        label: {
                            show: true, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras

                        },
                        dataset: [{
                            source: response.division,
                            dimensions: ['division', 'ordenes', 'garantias', 'cambaceos'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                interval: 0,
                                rotate: 90 // Rotación de las etiquetas del eje y
                            }
                        },
                        yAxis: {},
                        series: [{
                                name: 'Ordenes',
                                type: 'bar',

                                encode: {
                                    y: 'ordenes',
                                    x: 'division'
                                },
                                itemStyle: {
                                    color: '#4F71F1' // Cambiar el color de las barras de órdenes
                                },
                                emphasis: {
                                    focus: 'series'
                                },
                                datasetIndex: 0
                            },
                            {
                                name: 'Garantias',
                                type: 'bar',
                                encode: {
                                    y: 'garantias',
                                    x: 'division'
                                },
                                itemStyle: {
                                    color: '#4FF1D4' // Cambiar el color de las barras de garantías
                                },
                                datasetIndex: 0,
                                emphasis: {
                                    focus: 'series'
                                },

                            },
                            {
                                name: 'Cambaceos',
                                type: 'bar',
                                encode: {
                                    y: 'cambaceos',
                                    x: 'division'
                                },
                                itemStyle: {
                                    color: '#56F14F' // Cambiar el color de las barras de garantías
                                },
                                datasetIndex: 0,
                                emphasis: {
                                    focus: 'series'
                                },

                            }
                        ]
                    };

                    grafico_prod__division.setOption(option);
                    grafico_prod__division.on('click', function(params) {
                        if (params.seriesName === 'Ordenes') {
                            var urlDestino = 'ordenes.php?inicio=' + encodeURIComponent(requestData.inicio) + '&fin=' + encodeURIComponent(requestData.fin)
                            // Redirecciona a la página deseada con los parámetros de fecha
                            window.location.href = urlDestino;
                        }
                    });

                    function number_format(number) {
                        if (number !== undefined && number !== null) {
                            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                        } else {
                            return ""; // O cualquier valor predeterminado que desees devolver en caso de que el número sea undefined o null
                        }
                    }
                    if (
                        response.hasOwnProperty("tareas") && response.hasOwnProperty("ordenes") && response.hasOwnProperty("garantias") && response.hasOwnProperty("cambaceos")
                    ) {
                        // Acceder a los datos y actualizar la interfaz de usuario
                        $("#total_tareas").html(number_format(response.tareas));
                        $("#total_ordenes").html(number_format(response.ordenes));
                        $("#total_garantias").html(number_format(response.garantias));
                        $("#total_cambaceo").html(number_format(response.cambaceos));

                    } else {
                        // Manejar el caso en que la respuesta del servidor sea incorrecta
                        console.error(
                            "La respuesta del servidor no contiene los datos esperados."
                        );
                    }

                    var dataProd = response.prod;
                    var semanas = dataProd.map(item => item[0]);
                    var productividad = dataProd.map(item => item[1]);
                    var garantias = dataProd.map(item => item[2]);
                    var cambaceos = dataProd.map(item => item[3]);

                    option = {
                        title: {
                            text: 'Productividad',
                            left: 'center',
                            top: '5%'
                        },
                        tooltip: {
                            trigger: 'axis'
                        },
                        legend: {
                            data: ['Ordenes', 'Garantias', 'Cambaceos']
                        },
                        grid: {
                            left: '3%',
                            right: '7%',
                            bottom: '10%',
                            containLabel: true
                        },
                        toolbox: {
                            feature: {
                                saveAsImage: {}
                            }
                        },
                        xAxis: {
                            type: 'category',
                            boundaryGap: false,
                            data: semanas
                        },
                        yAxis: {
                            type: 'value'
                        },
                        series: [{
                                name: 'Ordenes',
                                type: 'line',
                                data: productividad
                            },
                            {
                                name: 'Garantias',
                                type: 'line',
                                stack: 'Total',
                                data: garantias
                            },
                            {
                                name: 'Cambaceos',
                                type: 'line',
                                stack: 'Total',
                                data: cambaceos
                            },
                        ]
                    };
                    grafico_prod_empresa.setOption(option)

                },
                error: function(xhr, status, error) {
                    console.error('Error al obtener los datos de la gráfica:', error);
                }
            });


        }

        // Inicializa el Date Range Picker
        $('#reportrange').daterangepicker({
            startDate: moment().startOf('month'), // Ejemplo de fecha de inicio
            endDate: moment().endOf('month'),
            ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Últimos 7 Días': [moment().subtract(6, 'days'), moment()],
                'Últimos 30 Días': [moment().subtract(29, 'days'), moment()],
                'Este Mes': [moment().startOf('month'), moment().endOf('month')],
                'Mes Pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            locale: {

                format: 'MMMM D, YYYY',
                separator: ' - ',
                applyLabel: 'Aplicar',
                cancelLabel: 'Cancelar',
                fromLabel: 'Desde',
                toLabel: 'Hasta',
                customRangeLabel: 'Rango personalizado',
                weekLabel: 'S',
                daysOfWeek: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
                monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                firstDay: 1
            }

        }, cb);
        cb(moment().startOf('month'), moment().endOf('month'));


    });
</script>