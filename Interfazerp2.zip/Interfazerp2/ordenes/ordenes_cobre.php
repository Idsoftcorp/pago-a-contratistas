<?php
session_start();

// Si el usuario no ha iniciado sesión, redirigir al formulario de inicio de sesión
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: ../login.php");
    exit();
}
include('../includes/header.php');
?>
<div class="container-fluid">
    <div class="mb-3">
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                <li class="breadcrumb-item"><a href="ordenes.php">Ordenes</a></li>
                <li class="breadcrumb-item"><a href="ordenes_completadas.php">Completadas</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cobre</li>
            </ol>
            <h4 class="text-center">Ordenes Completadas</h4>
        </nav>
    </div>
    <div id="reportrange" class="form-control" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%; margin-bottom:20px; text-align: center;">
        <i class="fa fa-calendar"></i> &nbsp;
        <span><i class="fa fa-caret-down"></i></span>
    </div>
</div>

<div class="container-fluid">
    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
        <div class="card  mx-2 " style="width:700px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_area" style="height: 1000px; "></div>
        </div>
        <div class="card  mx-2 " style="width:450px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive " id="grafica_cope" style="height: 500px;"></div>
        </div>
    </div>


</div>
<div class="container-fluid">
    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">

        <div class="card  mx-2 " style="width:600px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_contratista" style="height: 500px; "></div>
        </div>
        <div class="card  mx-2 " style="width:550px; height:500px;">
            <!-- Contenedor para la gráfica -->
            <div class="responsive" id="grafica_tecnico" style="height: 500px; "></div>
        </div>
        <!--  -->
    </div>
</div>
<?php include('../includes/footer.php') ?>
<script>
    $(document).ready(function() {
        var grafico_area = echarts.init(document.getElementById('grafica_area'));
        var grafico_prod_division = echarts.init(document.getElementById('grafica_cope'));
        var grafico_prod_contratista = echarts.init(document.getElementById('grafica_contratista'));
        var grafico_prod_tecnico = echarts.init(document.getElementById('grafica_tecnico'));

        var urlParams = new URLSearchParams(window.location.search);
        var division = urlParams.get('division');
        var start = urlParams.has('inicio') ? moment(urlParams.get('inicio')) : moment().subtract(30, 'days');
        var end = urlParams.has('fin') ? moment(urlParams.get('fin')) : moment();
        window.history.pushState({}, document.title, window.location.pathname);


        function cb(start, end, division) {
            $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            var requestData = {
                division: division,
                inicio: start.format('YYYY-MM-DD'), // Formatea la fecha de inicio
                fin: end.format('YYYY-MM-DD'),
            };
            $.ajax({
                url: '../consultas/ordenes_cobre_query.php',
                type: 'GET',
                dataType: 'json',
                data: requestData,
                success: function(response) {
                    // Actualiza la gráfica con los datos obtenidos

                    option_area = {
                        title: {
                            text: 'Areas-Division: ' + requestData.division,
                            left: 'center',
                            top: 15,
                            z: 5
                        },

                        tooltip: {
                            trigger: 'item'
                        },
                        label: {
                            show: true, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras
                        },
                        legend: {
                            top: '8%',
                            left: 'center',
                        },
                        grid: {
                            top: '20%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        dataset: [{
                            source: response.area,
                            dimensions: ['area', 'fibra'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                rotate: 50,
                            },
                            axisTick: {
                                show: false,
                            },
                        },
                        yAxis: {},
                        series: [{
                            name: 'Fibra',
                            type: 'bar',
                            encode: {
                                y: 'fibra',
                                x: 'area'
                            },
                            itemStyle: {
                                color: '#564BFD' // Cambiar el color de las barras de órdenes
                            },
                            barWidth: '40%',
                            emphasis: {
                                focus: 'series'
                            },
                            datasetIndex: 0
                        }]
                    };
                    grafico_area.setOption(option_area);
                    grafico_area.on('click', function(params) {

                        var dimensionIndex = params.dimensionNames.indexOf('area'); // Índice de la dimensión 'area'
                        var area = params.value[dimensionIndex]; // Valo;
                        graficaPorCope(area, requestData.inicio,requestData.fin)
                        // console.log(area)
                    });

                },
                error: function(xhr, status, error) {
                    console.error('Error al obtener los datos de la gráfica:', error);
                }
            });

        }
        // Verificar si se encontró el parámetro 'division' en la URL

        function graficaPorCope(area, inicio, fin) {

            var requestData = {
                area: area,
                inicio: inicio,
                fin: fin,
            }
            $.ajax({
                url: '../consultas/ordenes_cobre_query.php',
                type: 'GET',
                dataType: 'json',
                data: requestData,
                success: function(response) {
                    option = {
                        title: {
                            text: 'Copes-Area: '+requestData.area,
                            left: 'center',
                            top: 20,
                            z: 5

                        },
                        tooltip: {
                            trigger: 'item'
                        },
                        legend: {
                            top: '10%',
                            left: 'center'
                        },
                        grid: {
                            top: '18%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        label: {
                            show: true, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras

                        },
                        dataset: [{
                            source: response.cope,
                            dimensions: ['cope', 'fibra'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                interval: 0,
                                rotate: 50 // Rotación de las etiquetas del eje y
                            }
                        },
                        yAxis: {},
                        series: [{
                            name: 'Fibra',
                            type: 'bar',

                            encode: {
                                y: 'fibra',
                                x: 'cope'
                            },
                            itemStyle: {
                                color: '#564BFD' // Cambiar el color de las barras de órdenes
                            },
                            emphasis: {
                                focus: 'series'
                            },
                            datasetIndex: 0
                        }]
                    };

                    grafico_prod_division.setOption(option);
                    grafico_prod_division.on('click', function(params) {

                        var dimensionIndex = params.dimensionNames.indexOf('cope'); // Índice de la dimensión 'area'
                        var cope = params.value[dimensionIndex]; // Valo;
                        graficaPorContratista(cope, requestData.inicio,requestData.fin);
                        // console.log(cope)
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error al obtener los datos de la gráfica por Cope:', error);
                }
            });
        }

        function graficaPorContratista(cope, inicio, fin) {
            var requestData = {
                cope: cope,
                inicio: inicio,
                fin: fin,
            }
            $.ajax({
                url: '../consultas/ordenes_cobre_query.php',
                type: 'GET',
                dataType: 'json',
                data: requestData,
                success: function(response) {
                    option = {
                        title: {
                            text: 'Contratistas de: '+requestData.cope,
                            left: 'center',
                            top: 20,
                            z: 5

                        },
                        tooltip: {
                            trigger: 'item'
                        },
                        legend: {
                            top: '10%',
                            left: 'center'
                        },
                        grid: {
                            top: '18%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        label: {
                            show: true, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras

                        },
                        dataset: [{
                            source: response.contratista,
                            dimensions: ['contratista', 'fibra'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                interval: 0,
                                rotate: 50 // Rotación de las etiquetas del eje y
                            }
                        },
                        yAxis: {},
                        series: [{
                            name: 'Fibra',
                            type: 'bar',

                            encode: {
                                y: 'fibra',
                                x: 'contratista'
                            },
                            itemStyle: {
                                color: '#564BFD' // Cambiar el color de las barras de órdenes
                            },
                            emphasis: {
                                focus: 'series'
                            },
                            datasetIndex: 0
                        }]
                    };

                    grafico_prod_contratista.setOption(option);
                    grafico_prod_contratista.on('click', function(params) {

                        var dimensionIndex = params.dimensionNames.indexOf('contratista'); // Índice de la dimensión 'area'
                        var contratista = params.value[dimensionIndex]; // Valo;
                        var cope = requestData.cope;
                        graficaPorTecnico(contratista, cope, requestData.inicio,requestData.fin);
                        // console.log(cope)
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error al obtener los datos de la gráfica por Cope:', error);
                }
            });
        }

        function graficaPorTecnico(contratista, cope, inicio, fin) {
            var requestData = {
                contratista: contratista,
                cope: cope,
                inicio: inicio,
                fin: fin,
            }
            $.ajax({
                url: '../consultas/ordenes_cobre_query.php',
                type: 'GET',
                dataType: 'json',
                data: requestData,
                success: function(response) {
                    var numTecnicos = response.tecnico.length;
                    option = {
                        title: {
                            text: 'Tecnicos de: '+requestData.contratista+' (' + numTecnicos + ' técnicos)',
                            left: 'center',
                            top: 20,
                            z: 5

                        },
                        tooltip: {
                            trigger: 'item'
                        },
                        legend: {
                            top: '10%',
                            left: 'center'
                        },
                        grid: {
                            top: '18%', // Ajustar la posición vertical de la gráfica
                            bottom: '30%' // Ajustar el margen inferior
                        },
                        label: {
                            show: true, // Mostrar etiquetas
                            position: 'top' // Colocar las etiquetas encima de las barras

                        },
                        dataset: [{
                            source: response.tecnico,
                            dimensions: ['contratista', 'fibra'],
                        }],
                        xAxis: {
                            type: 'category',
                            axisLabel: {
                                interval: 0,
                                rotate: 50 // Rotación de las etiquetas del eje y
                            }
                        },
                        yAxis: {},
                        series: [{
                            name: 'Fibra',
                            type: 'bar',

                            encode: {
                                y: 'fibra',
                                x: 'contratista'
                            },
                            itemStyle: {
                                color: '#564BFD' // Cambiar el color de las barras de órdenes
                            },
                            emphasis: {
                                focus: 'series'
                            },
                            datasetIndex: 0
                        }]
                    };

                    grafico_prod_tecnico.setOption(option);
                    grafico_prod_tecnico.on('click', function(params) {

                        var dimensionIndex = params.dimensionNames.indexOf('contratista'); // Índice de la dimensión 'area'
                        var contratista = params.value[dimensionIndex]; // Valo;
                        // graficaPorContratista(cope);

                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error al obtener los datos de la gráfica por Cope:', error);
                }
            });
        }


        $('#reportrange').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
                'Hoy': [moment(), moment()],
                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Últimos 7 Días': [moment().subtract(6, 'days'), moment()],
                'Últimos 30 Días': [moment().subtract(29, 'days'), moment()],
                'Este Mes': [moment().startOf('month'), moment().endOf('month')],
                'Mes Pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            locale: {
                format: 'MMMM D, YYYY',
                separator: ' - ',
                applyLabel: 'Aplicar',
                cancelLabel: 'Cancelar',
                fromLabel: 'Desde',
                toLabel: 'Hasta',
                customRangeLabel: 'Rango personalizado',
                weekLabel: 'S',
                daysOfWeek: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
                monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                firstDay: 1
            }

        }, function(start, end) {
            // Aquí envolvemos nuestro llamado a cb en una nueva función que asegura incluir division
            cb(start, end, division);
        });

        cb(start, end, division);

    });
</script>