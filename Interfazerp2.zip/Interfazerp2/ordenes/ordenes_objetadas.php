<?php
session_start();

// Si el usuario no ha iniciado sesión, redirigir al formulario de inicio de sesión
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: ../login.php");
    exit();
}
include('../includes/header.php') ?>
<div class="container-fluid">

    <div class="mb-3">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                <li class="breadcrumb-item"><a href="ordenes.php">Ordenes</a></li>
                <li class="breadcrumb-item active" aria-current="page">Objetadas</li>
            </ol>
            <h4 class="text-center">Ordenes Objetadas</h4>
        </nav>
    </div>


    <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
        <div class="card btn mx-2" style="align-items: center; width:70vh; height:20vh; background-color:#B74BFD;border:none">
            <div style="margin-top:10px">
                <h4 class="text-center text-white mt-4" style="font-size:35px"><a xstyle="text-decoration: none; color:white"><i class="fa-solid fa-user" style="display: inline-block;"></i>
                        <div id="fibra" style="display: inline-block;"></div> OS Fibra
                    </a></h4>
            </div>
        </div>

        <div class="card btn  mx-2 " style="width:70vh; height:20vh;background-color:#564BFD;border:none">
            <div style="margin-top:10px">
                <h4 class="text-center text-white mt-4 " style="font-size:35px"><a style="text-decoration: none; color:white"><i class="fa-solid fa-chart-line"></i>
                        <div id="cobre" style="display: inline-block;"></div> Os Cobre
                    </a></h4>
            </div>
        </div>
        <div id="reportrange" class="form-control" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 96%; margin-bottom:20px; text-align: center;">
            <i class="fa fa-calendar"></i> &nbsp;
            <span><i class="fa fa-caret-down"></i></span>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
            <div class="card  mx-2 " style="width:405px; height:500px;">
                <!-- Contenedor para la gráfica -->
                <div class="responsive" id="grafica_ordenes" style="height: 500px; "></div>
            </div>
            <div class="card  mx-2 " style="width:760px; height:500px;">
                <!-- Contenedor para la gráfica -->
                <div class="responsive " id="grafica2" style="height: 500px;"></div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row" style=" display: flex; align-items: center; justify-content: center; ">
            <div class="card  mx-2" style="width:1270px; height:500px;">
                <!-- Contenedor para la gráfica -->
                <div class="responsive" id="grafica_area" style="height: 1000px; "></div>
            </div>

        </div>
    </div>
    <?php include('../includes/footer.php') ?>

    <script>
        $(document).ready(function() {

            var grafico_ordenes = echarts.init(document.getElementById('grafica_ordenes'));
            var grafico_div = echarts.init(document.getElementById('grafica2'));
            var grafico_area = echarts.init(document.getElementById('grafica_area'));
            var urlParams = new URLSearchParams(window.location.search);
            var division = urlParams.get('division');
            var start = urlParams.has('inicio') ? moment(urlParams.get('inicio')) : moment().subtract(30, 'days');
            var end = urlParams.has('fin') ? moment(urlParams.get('fin')) : moment();

            function cb(start, end, division) {
                var requestData = {
                    division: division,
                    inicio: start.format('YYYY-MM-DD'), // Formatea la fecha de inicio
                    fin: end.format('YYYY-MM-DD'),
                };
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                $.ajax({
                    url: '../consultas/ordenes_objetadas_query.php',
                    type: 'GET',
                    dataType: 'json',
                    data: requestData,
                    success: function(data) {

                        var opciones = {
                            title: {
                                text: 'Ordenes de cobre',
                                left: 'center',
                                top: 20,
                                z: 5,

                            },
                            tooltip: {
                                trigger: 'item',
                                formatter: '{a} <br/>{b}: {c} ({d}%)',
                            },
                            legend: {
                                top: '10%',
                                left: 'center',

                            },
                            series: [{
                                top: '5%',
                                name: '',
                                type: 'pie',
                                radius: ['40%', '80%'],
                                avoidLabelOverlap: false,
                                itemStyle: {
                                    borderRadius: 10,
                                    borderColor: '#fff',
                                    borderWidth: 4
                                },
                                label: {
                                    show: false,
                                    position: 'center'
                                },

                                labelLine: {
                                    show: true
                                },
                                data: [{
                                    value: data.fibra,
                                    name: 'Fibra',
                                    // emphasis: {
                                    //     focus: 'series'
                                    // },
                                    itemStyle: {
                                        color: '#B74BFD', // Cambiar el color de las barras de órdenes
                                    },

                                    label: {
                                        show: true, // Mostrar el valor sobre la barra
                                        position: 'inside', // Posición del valor (puede ser 'top', 'insideTop', 'inside', etc.)
                                        formatter: '{d}%',

                                    }

                                }, {
                                    value: data.cobre,
                                    name: 'Cobre',
                                    // emphasis: {
                                    //     focus: 'series'
                                    // },
                                    itemStyle: {
                                        color: '#564BFD', // Cambiar el color de las barras de órdenes
                                    },

                                    label: {
                                        show: true, // Mostrar el valor sobre la barra
                                        position: 'inside', // Posición del valor (puede ser 'top', 'insideTop', 'inside', etc.)
                                        formatter: '{d}%'
                                    }
                                }]
                            }]
                        };
                        // var grafico_liquidadas = echarts.init(document.getElementById('grafico_liquidadas'));
                        grafico_ordenes.setOption(opciones);
                        grafico_ordenes.on('click', function(params) {
                            // Verifica si el clic se realizó en la barra de "Ordenes"
                            if (params.name === 'Ordenes') {
                                // Redirecciona a la página deseada
                                // window.location.href = 'ordenes.php';
                            }
                        });

                        option = {
                            title: {
                                text: 'Ordenes division',
                                left: 'center',
                                top: 20,
                                z: 5

                            },
                            tooltip: {
                                trigger: 'item'
                            },
                            legend: {
                                top: '10%',
                                left: 'center'
                            },
                            grid: {
                                top: '18%', // Ajustar la posición vertical de la gráfica
                                bottom: '30%' // Ajustar el margen inferior
                            },
                            label: {
                                show: true, // Mostrar etiquetas
                                position: 'top' // Colocar las etiquetas encima de las barras


                            },
                            dataset: [{
                                source: data.division,
                                dimensions: ['division', 'fibra', 'cobre', ],
                            }],
                            xAxis: {
                                type: 'category',
                                axisLabel: {
                                    interval: 0,
                                    rotate: 50 // Rotación de las etiquetas del eje y
                                }
                            },
                            yAxis: {},
                            series: [{
                                    name: 'fibra',
                                    type: 'bar',

                                    encode: {
                                        y: 'fibra',
                                        x: 'division'
                                    },
                                    itemStyle: {
                                        color: '#B74BFD' // Cambiar el color de las barras de órdenes
                                    },
                                    emphasis: {
                                        focus: 'series'
                                    },
                                    datasetIndex: 0.

                                },
                                {
                                    name: 'cobre',
                                    type: 'bar',
                                    encode: {
                                        y: 'cobre',
                                        x: 'division'
                                    },
                                    itemStyle: {
                                        color: '#564BFD' // Cambiar el color de las barras de garantías
                                    },
                                    datasetIndex: 0,
                                    emphasis: {
                                        focus: 'series'
                                    },

                                }
                            ]
                        };

                        grafico_div.setOption(option);
                        grafico_div.on('click', function(params) {
                            var division = params.seriesName;

                            // Obtener el índice de los datos de la barra clicada
                            var dataIndex = params.dataIndex;

                            // Obtener el array correspondiente al índice
                            var dataArray = option.dataset[0].source;

                            // Obtener los datos de la división correspondientes al índice
                            var divisionData = dataArray[dataIndex];

                            // Obtener el nombre o el ID de la división desde la sub-array
                            var divisionName = divisionData[0]; // Suponiendo que la propiedad division está en la primera posición del sub-array

                            if (divisionName) {
                                // Redirigir a la página deseada incluyendo el nombre de la división como parámetro en la URL
                                if (division === 'fibra') {
                                    window.location.href = 'ordenes_fibra_obj.php?division=' + encodeURIComponent(divisionName) + '&inicio=' + encodeURIComponent(requestData.inicio) + '&fin=' + encodeURIComponent(requestData.fin);
                                } else if (division === 'cobre') {
                                    window.location.href = 'ordenes_cobre_obj.php?division=' + encodeURIComponent(divisionName) + '&inicio=' + encodeURIComponent(requestData.inicio) + '&fin=' + encodeURIComponent(requestData.fin);

                                }
                            } else {
                                console.error(data.division);
                            }
                        });

                        option_area = {
                            title: {
                                text: 'Ordenes de area',
                                left: 'center',
                                top: 15,
                                z: 5
                            },

                            tooltip: {
                                trigger: 'item'
                            },
                            label: {
                                show: false, // Mostrar etiquetas
                                position: 'top' // Colocar las etiquetas encima de las barras
                            },
                            legend: {
                                top: '8%',
                                left: 'center',
                            },
                            grid: {
                                top: '20%', // Ajustar la posición vertical de la gráfica
                                bottom: '30%' // Ajustar el margen inferior
                            },
                            dataset: [{
                                source: data.area,
                                dimensions: ['area', 'fibra', 'cobre'],
                            }],
                            xAxis: {
                                type: 'category',
                                axisLabel: {
                                    rotate: 50,
                                },
                                axisTick: {
                                    show: false,
                                },
                            },
                            yAxis: {},
                            series: [{
                                    name: 'fibra',
                                    type: 'bar',
                                    encode: {
                                        y: 'fibra',
                                        x: 'area'
                                    },
                                    itemStyle: {
                                        color: '#B74BFD' // Cambiar el color de las barras de órdenes
                                    },
                                    barWidth: '40%',
                                    emphasis: {
                                        focus: 'series'
                                    },
                                    datasetIndex: 0
                                },
                                {
                                    name: 'cobre',
                                    type: 'bar',
                                    encode: {
                                        y: 'cobre',
                                        x: 'area'
                                    },
                                    barWidth: '40%',
                                    itemStyle: {
                                        color: '#564BFD' // Cambiar el color de las barras de garantías
                                    },
                                    emphasis: {
                                        focus: 'series'
                                    },
                                    datasetIndex: 0
                                }
                            ]
                        };
                        grafico_area.setOption(option_area);
                        grafico_area.on('click', function(params) {
                            if (params.seriesName === 'Ordenes') {
                                window.location.href = 'ordenes.php';
                            }
                        });

                        function number_format(number) {
                            if (number !== undefined && number !== null) {
                                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            } else {
                                return ""; // O cualquier valor predeterminado que desees devolver en caso de que el número sea undefined o null
                            }
                        }
                        if (
                            data.hasOwnProperty("ordenes") && data.hasOwnProperty("fibra") && data.hasOwnProperty("cobre")
                        ) {
                            // Acceder a los datos y actualizar la interfaz de usuario
                            // $("#total_ordenes").html(number_format(data.total_cobre));
                            $("#fibra").html(number_format(data.fibra));
                            $("#cobre").html(number_format(data.cobre));

                        } else {
                            // Manejar el caso en que la respuesta del servidor sea incorrecta
                            console.error(
                                "La respuesta del servidor no contiene los datos esperados."
                            );
                        }

                    },
                    error: function(xhr, status, error) {
                        console.error('Error al obtener los datos de la gráfica:', error);
                    }
                });
            }


            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Hoy': [moment(), moment()],
                    'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Últimos 7 Días': [moment().subtract(6, 'days'), moment()],
                    'Últimos 30 Días': [moment().subtract(29, 'days'), moment()],
                    'Este Mes': [moment().startOf('month'), moment().endOf('month')],
                    'Mes Pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                locale: {
                    format: 'MMMM D, YYYY',
                    separator: ' - ',
                    applyLabel: 'Aplicar',
                    cancelLabel: 'Cancelar',
                    fromLabel: 'Desde',
                    toLabel: 'Hasta',
                    customRangeLabel: 'Rango personalizado',
                    weekLabel: 'S',
                    daysOfWeek: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
                    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                    firstDay: 1
                }

            }, function(start, end) {
                // Aquí envolvemos nuestro llamado a cb en una nueva función que asegura incluir division
                cb(start, end, division);
            });

            cb(start, end, division);
        });
    </script>