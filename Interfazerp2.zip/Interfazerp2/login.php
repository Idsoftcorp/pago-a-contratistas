<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <!-- Agrega enlaces a los estilos de Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <!-- Estilos CSS personalizados -->
</head>
<body>
  <br>
  <br>
  <br>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="login-form">
                    <h2>Iniciar sesión</h2>
                     <!-- Div para mostrar mensajes de error -->
    <div id="errorDiv" style="color: red;"></div>
                    <form action="controllers/login.php" method="post">
                        <div class="form-group">
                            <label for="nombre_usuario">Nombre de usuario:</label>
                            <input type="text" id="nombre_usuario" name="nombre_usuario" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña:</label>
                            <input type="password" id="contrasena" name="contrasena" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Iniciar sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Agrega la librería de JavaScript de Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Script para mostrar mensajes de error -->
    <script>
        // Obtener el mensaje de error de la URL (si lo hay)
        const urlParams = new URLSearchParams(window.location.search);
        const errorMessage = urlParams.get('error');
        
        // Mostrar el mensaje de error si existe
        if (errorMessage) {
            const errorDiv = document.getElementById('errorDiv');
            errorDiv.textContent = errorMessage;
        }
    </script>
</body>
</html>
