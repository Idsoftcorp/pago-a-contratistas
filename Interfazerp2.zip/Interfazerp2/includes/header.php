<?php date_default_timezone_set('America/Mexico_City') ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../static/css/estilos.css">
    <link rel="stylesheet" href="../static/fontawesome-free-6.5.1-web/css/all.min.css">

    <link href="../static/bootstrap-5.3.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Si estás utilizando componentes de JavaScript, también enlaza los archivos JS -->
    <script src="../static/bootstrap-5.3.2-dist/js/bootstrap.bundle.min.js"></script>
    <!-- Link Datatables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- DataTables JS -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <!-- DataTables Buttons CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.1.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <title>Index</title>
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="js-sidebar">
            <!-- Content For Sidebar -->
            <div class="h-100">
                <div class="sidebar-logo">
                    <img src="../static/img/Enlace.png" width="60px" height="50px">
                    <a href="index.php" style="margin-left: 8px;"><strong style="color:green;">Enlace</strong><strong style="color:gray;"> digital</strong> </a>
                </div>
                <ul class="sidebar-nav">
                    <li class="sidebar-header">
                        Panel de Administrador
                    </li>
                    <hr style="color: white;">
                    <li class="sidebar-item">
                        <a href="index.php" class="sidebar-link">
                            <i class="fa-solid fa-list pe-2"></i>
                            Dashboard de producción
                        </a>
                    </li>

                   <!--  <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#compras" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-ticket pe-2">
                            </i> Pago a contratistas
                        </a>
                        <ul id="compras" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Órdenes de servicio</a>
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#liquidadasSubMenu">- Órdenes de Servicio</a>
                                                            
                            </li>
                            <li class="sidebar-item">
                                <a href="proveedores.php" class="sidebar-link">Procesos</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Reportes</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Catálogos</a>
                            </li>

                        </ul>
                    </li> -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#tareas" data-bs-toggle="collapse" aria-expanded="false">
                            <i class="fa-solid fa-ticket pe-2"></i> Pago a contratistas
                        </a>
                        <ul id="tareas" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#liquidadasSubMenu">- Órdenes de Servicio</a>
                                <ul id="liquidadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="view.php" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreSubMenu">Carga</a>
                                        <!-- <ul id="cobreSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="/interfazerp/ordenes/ordenes_fibra.php" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">*Reagendada</a>
                                            </li>
                                        </ul> -->
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraSubMenu">Evidencias</a>
                                        <ul id="fibraSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoSubMenu">Estatus</a>
                                        <ul id="cambaceoSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                        <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#objetadasSubMenu">- Garantías</a>
                                <ul id="objetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreObjetadasSubMenu">Quejas</a>
                                        <ul id="cobreObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <!-- <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraObjetadasSubMenu">Fibra</a>
                                        <ul id="fibraObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Completada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Objetada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Reagendada</a>
                                            </li>

                                        </ul>
                                    </li> -->
                                    <!-- <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoObjetadasSubMenu">Cambaceo</a>
                                        <ul id="cambaceoObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Completada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Objetada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Reagendada</a>
                                            </li>
                                        </ul>
                                    </li> -->
                                </ul>
                            </li>

                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#reagendadasSubMenu">- Cambaceos</a>
                                <ul id="reagendadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreSubMenu">Completadas</a>
                                        <ul id="cobreSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                            <!-- <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">*Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraSubMenu">Objetadas</a>
                                        <ul id="fibraSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoSubMenu">Reagendadas</a>
                                        <ul id="cambaceoSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                        <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <!-- <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#garantiasSubMenu">-Garantias</a>
                                <ul id="garantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreGarantiasSubMenu">Cobre</a>
                                        <ul id="cobreGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Cobre Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Cobre Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraGarantiasSubMenu">Fibra</a>
                                        <ul id="fibraGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                           <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Fibra Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Fibra Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoGarantiasSubMenu">Cambaceo</a>
                                        <ul id="cambaceoGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Cambaceo Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Cambaceo Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> -->

                        </ul>
                    </li>

                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#tareas" data-bs-toggle="collapse" aria-expanded="false">
                            <i class="fa-solid fa-ticket pe-2"></i> Tareas
                        </a>
                        <ul id="tareas" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#liquidadasSubMenu">- Órdenes de Servicio</a>
                                <ul id="liquidadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreSubMenu">Completadas</a>
                                        <ul id="cobreSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="/interfazerp/ordenes/ordenes_fibra.php" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                            <!-- <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">*Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraSubMenu">Objetadas</a>
                                        <ul id="fibraSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoSubMenu">Reagendadas</a>
                                        <ul id="cambaceoSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                        <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#objetadasSubMenu">- Garantías</a>
                                <ul id="objetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreObjetadasSubMenu">Quejas</a>
                                        <ul id="cobreObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <!-- <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraObjetadasSubMenu">Fibra</a>
                                        <ul id="fibraObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Completada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Objetada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Reagendada</a>
                                            </li>

                                        </ul>
                                    </li> -->
                                    <!-- <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoObjetadasSubMenu">Cambaceo</a>
                                        <ul id="cambaceoObjetadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Completada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Objetada</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">* Reagendada</a>
                                            </li>
                                        </ul>
                                    </li> -->
                                </ul>
                            </li>

                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#reagendadasSubMenu">- Cambaceos</a>
                                <ul id="reagendadasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreSubMenu">Completadas</a>
                                        <ul id="cobreSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                            <!-- <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">*Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraSubMenu">Objetadas</a>
                                        <ul id="fibraSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                           <!--  <li class="sidebar-item">
                                                <a href="#" class="sidebar-link"> * Reagendada</a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoSubMenu">Reagendadas</a>
                                        <ul id="cambaceoSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                        <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Fibra</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Cobre</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <!-- <li class="sidebar-item">
                                <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#garantiasSubMenu">-Garantias</a>
                                <ul id="garantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cobreGarantiasSubMenu">Cobre</a>
                                        <ul id="cobreGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Cobre Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Cobre Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#fibraGarantiasSubMenu">Fibra</a>
                                        <ul id="fibraGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                           <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Fibra Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Fibra Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sidebar-item">
                                        <a href="#" class="sidebar-link" data-bs-toggle="collapse" data-bs-target="#cambaceoGarantiasSubMenu">Cambaceo</a>
                                        <ul id="cambaceoGarantiasSubMenu" class="sidebar-dropdown list-unstyled collapse">
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 1 de Cambaceo Garantias</a>
                                            </li>
                                            <li class="sidebar-item">
                                                <a href="#" class="sidebar-link">Submódulo 2 de Cambaceo Garantias</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> -->

                        </ul>
                    </li>

                   

                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#clientes" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-users"></i><span style="margin-left: 10px;">Contratistas</span>
                        </a>
                        <ul id="clientes" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                        <li class="sidebar-item">
                                <a href="mapa.php" class="sidebar-link">Tablas de precios</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="mapa.php" class="sidebar-link">Concentrado contratistas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="mapa.php" class="sidebar-link">Mapa de contratistas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">modulo 2</a>
                            </li>
                        </ul>
                    </li>





                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#facturacion" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-ticket pe-2">
                            </i> Contabilidad
                        </a>
                        <ul id="facturacion" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="proveedores.php" class="sidebar-link">Facturación</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Reportes por contratista</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Descuentos</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="compras.php" class="sidebar-link">Saldos acreedores</a>
                            </li>

                        </ul>
                    </li>

                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#posts" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-chart-line"></i><span style="margin-left: 10px;"> Auditorías</span>
                        </a>
                        <ul id="posts" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="Auditorias.php" class="sidebar-link">> Auditorias de campo</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">>Auditorías telefónicas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">> Post 3</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#posts" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-chart-line"></i><span style="margin-left: 10px;"> Estadísticos</span>
                        </a>
                        <ul id="posts" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="estadisticas.php" class="sidebar-link">> Estadisiticas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">> Post 2</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">> Post 3</a>
                            </li>
                        </ul>
                    </li>
                    <!-- <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#contro-vehicular" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-gauge"></i><span style="margin-left: 10px;"> Control Vehicular</span>
                        </a>
                        <ul id="contro-vehicular" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar" style="margin-left: 10px;">
                            <li class="sidebar-item">
                                <a href="operadores.php" class="sidebar-link"><i class="fa-solid fa-user"></i> Operadores</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="unidades.php" class="sidebar-link"><i class="fa-solid fa-truck-pickup"></i> Unidades registradas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link"><i class="fa-solid fa-car-burst"></i> Unidades con anomalias</a>
                            </li>
                        </ul>
                    </li> -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#auth" data-bs-toggle="collapse" aria-expanded="false"> <i class="fa-solid fa-gears"></i><span style="margin-left: 10px;"> Ajustes</span>
                        </a>
                        <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">Login</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">Register</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">Forgot Password</a>
                            </li>
                        </ul>
                    </li>

                    <li class="sidebar-item">
                        <a href="" class="sidebar-link">
                            <i class="fa-regular fa-circle-question"></i><span style="margin-left: 10px;"> Ayuda</span>
                        </a>
                    </li>
                    <!-- <li class="sidebar-item">
                        <a href="" class="sidebar-link">
                            <i class="fa-regular fa-circle-question"></i><span style="margin-left: 10px;"> Usuarios</span>
                        </a>
                    </li> -->
                    <hr style="color: white;">

                </ul>
            </div>
        </aside>
        <div class="main">
            <nav class="navbar navbar-expand px-3 border-bottom">
                <button class="btn" id="sidebar-toggle" type="button">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <a href="#" style="margin-left: 8px;"><strong style="color:green;">Enlace</strong><strong style="color:gray;"> digital</strong> </a>

                <form action="" style="margin-left:40px; margin-right:40px" class="col-sm-4">
                    <input class="form-control" type="text" placeholder="Buscar...">
                </form>
                <div class="navbar-collapse navbar">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                             <!-- Botón para cerrar sesión -->
                             <form action="../controllers/logout.php" method="post">
                                <button type="submit">Cerrar sesión</button>
                            </form>
                            <!-- <a href="#" data-bs-toggle="dropdown" class="nav-icon pe-md-0" style="text-decoration:none;">
                                <img src="../static/img/user-profile.png" class="avatar img-fluid rounded" alt="">
                                Jonny Bernal
                            </a> -->

                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="#" class="dropdown-item">Profile</a>
                                <a href="#" class="dropdown-item">Setting</a>
                                <a href="#" class="dropdown-item">Logout</a>
                            </div>

                        </li>
                    </ul>
                </div>
            </nav>
            <main class="content px-3 py-2">
                