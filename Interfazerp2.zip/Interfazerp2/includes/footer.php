</main>
<a href="" class="theme-toggle">
    <i class="fa-regular fa-moon"></i>
    <i class="fa-regular fa-sun"></i>
</a>
<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <a href="#" class="text-muted">
                        <strong>CodzSwod</strong>
                    </a>
                </p>
            </div>
            <div class="col-6 text-end">
                <ul class="list-inline">
                    <li class="list-inline-item">
                        <a href="#" class="text-muted">Contact</a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" class="text-muted">About Us</a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" class="text-muted">Terms</a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" class="text-muted">Booking</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="../static/DataTables/DataTables-1.13.8/js/jquery.dataTables.min.js"></script>
<script src="../static/bootstrap-5.3.2-dist/js/bootstrap.bundle.min.js"></script>
<script src="../static/js/script.js"></script>
<script src="../static/DataTables/DataTables-1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="../static/DataTables/JSZip-3.10.1/jszip.min.js"></script>
<script src="../static/DataTables/JSZip-3.10.1/jszip.js"></script>
<script src="../static/DataTables/Buttons-2.4.2/js/dataTables.buttons.min.js"></script>
<script src="../static/DataTables/Buttons-2.4.2/js/buttons.bootstrap5.min.js"></script>
<script src="../static/DataTables/Buttons-2.4.2/js/buttons.colVis.min.js"></script>
<script src="../static/DataTables/Buttons-2.4.2/js/buttons.html5.min.js"></script>
<script src="../static/DataTables/Buttons-2.4.2/js/buttons.print.min.js"></script>
<script src="../static/DataTables/pdfmake-0.2.7/pdfmake.min.js"></script>
<script src="../static/DataTables/pdfmake-0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.2.2/dist/echarts.min.js"></script>
<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment-with-locales.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

</body>

</html>